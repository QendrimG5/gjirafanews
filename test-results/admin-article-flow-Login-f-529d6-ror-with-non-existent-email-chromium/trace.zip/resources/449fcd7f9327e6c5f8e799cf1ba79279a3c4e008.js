(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__06.-pfn._.css","static/chunks/node_modules_0u5pe.y._.js","static/chunks/_0d8jmvp._.js"],
    source: "dynamic"
});
