(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0l-9g9j._.js","static/chunks/08s2_next_0-cgxxn._.js"],
    source: "dynamic"
});
