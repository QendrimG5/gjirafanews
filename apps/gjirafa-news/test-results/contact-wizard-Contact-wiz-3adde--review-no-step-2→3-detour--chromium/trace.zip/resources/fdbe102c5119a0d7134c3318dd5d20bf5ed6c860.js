(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/gjirafa-news/lib/contact-wizard/store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useWizard",
    ()=>useWizard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$12_$40$types$2b$react$40$19$2e$2$2e$14_immer$40$11$2e$1$2e$4_react$40$19$2e$2$2e$4_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$4_$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.12_@types+react@19.2.14_immer@11.1.4_react@19.2.4_use-sync-external-store@1.6.0_react@19.2.4_/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$12_$40$types$2b$react$40$19$2e$2$2e$14_immer$40$11$2e$1$2e$4_react$40$19$2e$2$2e$4_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$4_$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zustand@5.0.12_@types+react@19.2.14_immer@11.1.4_react@19.2.4_use-sync-external-store@1.6.0_react@19.2.4_/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
;
;
// Persist form state to localStorage for 10 minutes so users don't lose
// in-progress entries on accidental refresh. File uploads (Step 3) can't be
// serialized and are explicitly excluded — users will need to re-add files
// after a reload.
const TTL_MS = 10 * 60 * 1000;
const STORAGE_KEY = "gn-contact-wizard";
// Wraps localStorage with a timestamp envelope. On read, entries older than
// TTL_MS are deleted and treated as missing.
const ttlStorage = {
    getItem: (name)=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        const raw = window.localStorage.getItem(name);
        if (!raw) return null;
        try {
            const envelope = JSON.parse(raw);
            if (!envelope.ts || Date.now() - envelope.ts > TTL_MS) {
                window.localStorage.removeItem(name);
                return null;
            }
            return envelope.v;
        } catch  {
            window.localStorage.removeItem(name);
            return null;
        }
    },
    setItem: (name, value)=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        window.localStorage.setItem(name, JSON.stringify({
            ts: Date.now(),
            v: value
        }));
    },
    removeItem: (name)=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        window.localStorage.removeItem(name);
    }
};
const initialPersonal = {
    name: "",
    email: "",
    phone: ""
};
const initialPreferences = {
    userType: ""
};
const makeId = ()=>typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const useWizard = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$12_$40$types$2b$react$40$19$2e$2$2e$14_immer$40$11$2e$1$2e$4_react$40$19$2e$2$2e$4_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$4_$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$12_$40$types$2b$react$40$19$2e$2$2e$14_immer$40$11$2e$1$2e$4_react$40$19$2e$2$2e$4_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$4_$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((set, get)=>({
        step: 1,
        personal: initialPersonal,
        preferences: initialPreferences,
        documents: [],
        errors: {},
        returnTo: null,
        setStep: (s)=>set({
                step: s,
                errors: {},
                returnTo: null
            }),
        editStep: (s)=>set({
                step: s,
                errors: {},
                returnTo: 4
            }),
        next: ()=>{
            const { step, returnTo } = get();
            if (returnTo) {
                set({
                    step: returnTo,
                    errors: {},
                    returnTo: null
                });
                return;
            }
            if (step < 4) set({
                step: step + 1,
                errors: {}
            });
        },
        back: ()=>{
            const { step, returnTo } = get();
            if (returnTo) {
                // Cancel the edit and return to review without further validation.
                set({
                    step: returnTo,
                    errors: {},
                    returnTo: null
                });
                return;
            }
            if (step > 1) set({
                step: step - 1,
                errors: {}
            });
        },
        setPersonal: (p)=>set((state)=>({
                    personal: {
                        ...state.personal,
                        ...p
                    }
                })),
        setPreferences: (p)=>set((state)=>{
                // When userType changes, clear sibling fields so stale data from a
                // different branch doesn't leak into the submission. Initialize the
                // new branch's fields as empty strings (not undefined) so Zod's
                // `.min(n, "…")` message fires instead of a generic "Required".
                if (p.userType && p.userType !== state.preferences.userType) {
                    const base = {
                        userType: p.userType
                    };
                    if (p.userType === "individual") base.newsletter = false;
                    if (p.userType === "business") {
                        base.companyName = "";
                        base.vatNumber = "";
                    }
                    if (p.userType === "student") {
                        base.university = "";
                        base.graduationYear = "";
                    }
                    return {
                        preferences: base
                    };
                }
                return {
                    preferences: {
                        ...state.preferences,
                        ...p
                    }
                };
            }),
        addDocuments: (files)=>set((state)=>{
                console.log(files);
                const additions = files.map((file)=>({
                        id: makeId(),
                        file,
                        previewUrl: URL.createObjectURL(file),
                        name: file.name,
                        sizeBytes: file.size,
                        mime: file.type
                    }));
                return {
                    documents: [
                        ...state.documents,
                        ...additions
                    ]
                };
            }),
        removeDocument: (id)=>set((state)=>{
                const doomed = state.documents.find((d)=>d.id === id);
                if (doomed) URL.revokeObjectURL(doomed.previewUrl);
                return {
                    documents: state.documents.filter((d)=>d.id !== id)
                };
            }),
        setErrors: (e)=>set({
                errors: e
            }),
        reset: ()=>set((state)=>{
                for (const d of state.documents)URL.revokeObjectURL(d.previewUrl);
                return {
                    step: 1,
                    personal: initialPersonal,
                    preferences: initialPreferences,
                    documents: [],
                    errors: {},
                    returnTo: null
                };
            })
    }), {
    name: STORAGE_KEY,
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zustand$40$5$2e$0$2e$12_$40$types$2b$react$40$19$2e$2$2e$14_immer$40$11$2e$1$2e$4_react$40$19$2e$2$2e$4_use$2d$sync$2d$external$2d$store$40$1$2e$6$2e$0_react$40$19$2e$2$2e$4_$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>ttlStorage),
    // Only persist form data. Files, errors, and in-flight edit state are
    // intentionally excluded — Files can't survive JSON, and errors should
    // always start cleared after a reload.
    partialize: (state)=>({
            step: state.step,
            personal: state.personal,
            preferences: state.preferences
        }),
    version: 1
}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Stepper",
    ()=>Stepper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
const STEPS = [
    {
        n: 1,
        label: "Personal"
    },
    {
        n: 2,
        label: "Preferences"
    },
    {
        n: 3,
        label: "Documents"
    },
    {
        n: 4,
        label: "Review"
    }
];
function Stepper({ current }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
        className: "flex items-center justify-between gap-2",
        children: STEPS.map(({ n, label }, i)=>{
            const done = n < current;
            const active = n === current;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                className: "flex flex-1 items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-colors ${active ? "bg-gn-accent text-gn-text-inverse" : done ? "bg-gn-accent-muted text-gn-accent" : "bg-gn-overlay text-gn-text-tertiary"}`,
                        children: n
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx",
                        lineNumber: 20,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `hidden text-sm sm:inline ${active ? "text-gn-text font-medium" : "text-gn-text-tertiary"}`,
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx",
                        lineNumber: 31,
                        columnNumber: 13
                    }, this),
                    i < STEPS.length - 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "bg-gn-border-light h-px flex-1",
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx",
                        lineNumber: 39,
                        columnNumber: 15
                    }, this)
                ]
            }, n, true, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx",
                lineNumber: 19,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = Stepper;
var _c;
__turbopack_context__.k.register(_c, "Stepper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/lib/contact-wizard/schema.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FILE_LIMITS",
    ()=>FILE_LIMITS,
    "contactSubmissionSchema",
    ()=>contactSubmissionSchema,
    "documentFileSchema",
    ()=>documentFileSchema,
    "documentsSchema",
    ()=>documentsSchema,
    "personalInfoSchema",
    ()=>personalInfoSchema,
    "preferencesSchema",
    ()=>preferencesSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/classic/external.js [app-client] (ecmascript) <export * as z>");
;
const personalInfoSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().trim().min(2, "Name must be at least 2 characters").max(80),
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().trim().email("Enter a valid email address"),
    phone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().trim().regex(/^\+?[0-9\s\-()]{7,20}$/, "Enter a valid phone number")
});
const preferencesSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion("userType", [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        userType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("individual"),
        newsletter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().default(false)
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        userType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("business"),
        companyName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().trim().min(2, "Company name is required"),
        vatNumber: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().trim().regex(/^[A-Z]{2}[0-9A-Z]{2,12}$/, "Enter a valid VAT number")
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        userType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal("student"),
        university: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().trim().min(2, "University is required"),
        graduationYear: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().regex(/^\d{4}$/, "Enter a 4-digit year").refine((y)=>{
            const n = Number(y);
            return n >= 1950 && n <= new Date().getFullYear() + 10;
        }, "Year is out of range")
    })
]);
const MAX_FILE_BYTES = 5 * 1024 * 1024;
const ALLOWED_MIME = [
    "image/png",
    "image/jpeg",
    "image/webp",
    "application/pdf"
];
const documentFileSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].instanceof(File, {
    message: "Invalid file"
}).refine((f)=>f.size > 0, "File is empty").refine((f)=>f.size <= MAX_FILE_BYTES, "File must be ≤ 5 MB").refine((f)=>ALLOWED_MIME.includes(f.type), "Allowed: PNG, JPEG, WEBP, PDF");
const documentsSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(documentFileSchema).min(1, "Upload at least one document").max(5, "Maximum 5 documents");
const contactSubmissionSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$3$2e$6$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    personal: personalInfoSchema,
    preferences: preferencesSchema
});
const FILE_LIMITS = {
    maxBytes: MAX_FILE_BYTES,
    allowedMime: ALLOWED_MIME
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/field.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Field",
    ()=>Field
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function Field({ label, error, children, htmlFor }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        className: "block space-y-1.5",
        htmlFor: htmlFor,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-gn-text text-sm font-medium",
                children: label
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/field.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            children,
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-gn-danger block text-xs",
                role: "alert",
                children: error
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/field.tsx",
                lineNumber: 18,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/field.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = Field;
var _c;
__turbopack_context__.k.register(_c, "Field");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavButtons",
    ()=>NavButtons
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
const primaryCls = "bg-gn-accent hover:bg-gn-accent-light text-gn-text-inverse rounded-md px-4 py-2 text-sm font-medium transition-colors disabled:opacity-60";
const secondaryCls = "border-gn-border text-gn-text hover:bg-gn-overlay rounded-md border px-4 py-2 text-sm transition-colors disabled:opacity-40";
function NavButtons({ onBack, onNext, submitLabel = "Next", pending = false, isSubmit = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-between pt-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onBack,
                disabled: !onBack || pending,
                className: secondaryCls,
                children: "Back"
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            isSubmit ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "submit",
                disabled: pending,
                className: primaryCls,
                children: pending ? "Submitting…" : submitLabel
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx",
                lineNumber: 34,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: onNext,
                disabled: pending,
                className: primaryCls,
                children: submitLabel
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_c = NavButtons;
var _c;
__turbopack_context__.k.register(_c, "NavButtons");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepPersonalInfo",
    ()=>StepPersonalInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/field.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const inputCls = "border-gn-border bg-gn-surface text-gn-text placeholder:text-gn-text-tertiary focus:border-gn-accent focus:ring-gn-accent/20 w-full rounded-md border px-3 py-2 text-sm transition-colors focus:outline-none focus:ring-2";
function StepPersonalInfo() {
    _s();
    const personal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[personal]": (s)=>s.personal
    }["StepPersonalInfo.useWizard[personal]"]);
    const errors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[errors]": (s)=>s.errors
    }["StepPersonalInfo.useWizard[errors]"]);
    const setPersonal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[setPersonal]": (s)=>s.setPersonal
    }["StepPersonalInfo.useWizard[setPersonal]"]);
    const setErrors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[setErrors]": (s)=>s.setErrors
    }["StepPersonalInfo.useWizard[setErrors]"]);
    const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[next]": (s)=>s.next
    }["StepPersonalInfo.useWizard[next]"]);
    const back = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[back]": (s)=>s.back
    }["StepPersonalInfo.useWizard[back]"]);
    const isEditing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPersonalInfo.useWizard[isEditing]": (s)=>s.returnTo !== null
    }["StepPersonalInfo.useWizard[isEditing]"]);
    function handleNext() {
        const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["personalInfoSchema"].safeParse(personal);
        if (!parsed.success) {
            setErrors(parsed.error.flatten().fieldErrors);
            return;
        }
        setErrors({});
        next();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                label: "Name",
                error: errors.name?.[0],
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    className: inputCls,
                    placeholder: "e.g. Jane Doe (2–80 characters)",
                    value: personal.name,
                    onChange: (e)=>setPersonal({
                            name: e.target.value
                        }),
                    autoComplete: "name"
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                label: "Email",
                error: errors.email?.[0],
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "email",
                    className: inputCls,
                    placeholder: "name@example.com",
                    value: personal.email,
                    onChange: (e)=>setPersonal({
                            email: e.target.value
                        }),
                    autoComplete: "email"
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                    lineNumber: 42,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                label: "Phone",
                error: errors.phone?.[0],
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "tel",
                    className: inputCls,
                    placeholder: "+383 44 123 456",
                    value: personal.phone,
                    onChange: (e)=>setPersonal({
                            phone: e.target.value
                        }),
                    autoComplete: "tel"
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                    lineNumber: 52,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavButtons"], {
                onBack: isEditing ? back : undefined,
                onNext: handleNext,
                submitLabel: isEditing ? "Save" : "Next"
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(StepPersonalInfo, "oK7lDdHpgCY3KqE00SW9EjWbRkM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"]
    ];
});
_c = StepPersonalInfo;
var _c;
__turbopack_context__.k.register(_c, "StepPersonalInfo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepPreferences",
    ()=>StepPreferences
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/field.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const inputCls = "border-gn-border bg-gn-surface text-gn-text placeholder:text-gn-text-tertiary focus:border-gn-accent focus:ring-gn-accent/20 w-full rounded-md border px-3 py-2 text-sm transition-colors focus:outline-none focus:ring-2";
function StepPreferences() {
    _s();
    const preferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[preferences]": (s)=>s.preferences
    }["StepPreferences.useWizard[preferences]"]);
    const errors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[errors]": (s)=>s.errors
    }["StepPreferences.useWizard[errors]"]);
    const setPreferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[setPreferences]": (s)=>s.setPreferences
    }["StepPreferences.useWizard[setPreferences]"]);
    const setErrors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[setErrors]": (s)=>s.setErrors
    }["StepPreferences.useWizard[setErrors]"]);
    const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[next]": (s)=>s.next
    }["StepPreferences.useWizard[next]"]);
    const back = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[back]": (s)=>s.back
    }["StepPreferences.useWizard[back]"]);
    const isEditing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepPreferences.useWizard[isEditing]": (s)=>s.returnTo !== null
    }["StepPreferences.useWizard[isEditing]"]);
    function handleNext() {
        const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["preferencesSchema"].safeParse(preferences);
        if (!parsed.success) {
            setErrors(parsed.error.flatten().fieldErrors);
            return;
        }
        setErrors({});
        next();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                label: "I am a…",
                error: errors.userType?.[0],
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                    className: inputCls,
                    value: preferences.userType,
                    onChange: (e)=>setPreferences({
                            userType: e.target.value
                        }),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: "",
                            children: "Select one…"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 40,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: "individual",
                            children: "Individual"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: "business",
                            children: "Business"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                            value: "student",
                            children: "Student"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this),
            preferences.userType === "individual" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                label: "Subscribe to newsletter",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "text-gn-text-secondary flex items-center gap-2 text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "checkbox",
                            className: "accent-gn-accent h-4 w-4",
                            checked: !!preferences.newsletter,
                            onChange: (e)=>setPreferences({
                                    newsletter: e.target.checked
                                })
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 50,
                            columnNumber: 13
                        }, this),
                        "Send me occasional updates (optional)"
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                    lineNumber: 49,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                lineNumber: 48,
                columnNumber: 9
            }, this),
            preferences.userType === "business" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                        label: "Company name",
                        error: errors.companyName?.[0],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            className: inputCls,
                            placeholder: "e.g. Acme Ltd. (min. 2 characters)",
                            value: preferences.companyName ?? "",
                            onChange: (e)=>setPreferences({
                                    companyName: e.target.value
                                })
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 64,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                        lineNumber: 63,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                        label: "VAT number",
                        error: errors.vatNumber?.[0],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            className: inputCls,
                            placeholder: "e.g. XK12345678 (2 letters + 2–12 alphanumeric)",
                            value: preferences.vatNumber ?? "",
                            onChange: (e)=>setPreferences({
                                    vatNumber: e.target.value.toUpperCase()
                                })
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                        lineNumber: 71,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            preferences.userType === "student" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                        label: "University",
                        error: errors.university?.[0],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            className: inputCls,
                            placeholder: "e.g. University of Prishtina",
                            value: preferences.university ?? "",
                            onChange: (e)=>setPreferences({
                                    university: e.target.value
                                })
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 87,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                        lineNumber: 86,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Field"], {
                        label: "Graduation year",
                        error: errors.graduationYear?.[0],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            inputMode: "numeric",
                            maxLength: 4,
                            className: inputCls,
                            placeholder: "e.g. 2027 (4 digits, 1950–current+10)",
                            value: preferences.graduationYear ?? "",
                            onChange: (e)=>setPreferences({
                                    graduationYear: e.target.value
                                })
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                            lineNumber: 95,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                        lineNumber: 94,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavButtons"], {
                onBack: back,
                onNext: handleNext,
                submitLabel: isEditing ? "Save" : "Next"
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(StepPreferences, "1jpqe9BkMUq1omumKBhgy44ALZk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"]
    ];
});
_c = StepPreferences;
var _c;
__turbopack_context__.k.register(_c, "StepPreferences");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepDocuments",
    ()=>StepDocuments
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function StepDocuments() {
    _s();
    const documents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[documents]": (s)=>s.documents
    }["StepDocuments.useWizard[documents]"]);
    const errors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[errors]": (s)=>s.errors
    }["StepDocuments.useWizard[errors]"]);
    const addDocuments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[addDocuments]": (s)=>s.addDocuments
    }["StepDocuments.useWizard[addDocuments]"]);
    const removeDocument = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[removeDocument]": (s)=>s.removeDocument
    }["StepDocuments.useWizard[removeDocument]"]);
    const setErrors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[setErrors]": (s)=>s.setErrors
    }["StepDocuments.useWizard[setErrors]"]);
    const next = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[next]": (s)=>s.next
    }["StepDocuments.useWizard[next]"]);
    const back = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[back]": (s)=>s.back
    }["StepDocuments.useWizard[back]"]);
    const isEditing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepDocuments.useWizard[isEditing]": (s)=>s.returnTo !== null
    }["StepDocuments.useWizard[isEditing]"]);
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StepDocuments.useEffect": ()=>{
            return ({
                "StepDocuments.useEffect": ()=>{
                    for (const d of documents)URL.revokeObjectURL(d.previewUrl);
                }
            })["StepDocuments.useEffect"];
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["StepDocuments.useEffect"], []);
    function handleFiles(fileList) {
        console.log(fileList);
        if (!fileList?.length) return;
        addDocuments(Array.from(fileList));
    }
    function handleNext() {
        const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["documentsSchema"].safeParse(documents.map((d)=>d.file));
        if (!parsed.success) {
            const flat = parsed.error.flatten();
            const msgs = [
                ...flat.formErrors,
                ...Object.values(flat.fieldErrors).flat().filter(Boolean)
            ];
            setErrors({
                documents: msgs.length ? msgs : [
                    "Invalid files"
                ]
            });
            return;
        }
        setErrors({});
        next();
    }
    const accept = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FILE_LIMITS"].allowedMime.join(",");
    const maxMb = Math.round(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FILE_LIMITS"].maxBytes / (1024 * 1024));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onDragEnter: (e)=>{
                    e.preventDefault();
                    setIsDragging(true);
                },
                onDragOver: (e)=>e.preventDefault(),
                onDragLeave: ()=>setIsDragging(false),
                onDrop: (e)=>{
                    e.preventDefault();
                    setIsDragging(false);
                    handleFiles(e.dataTransfer.files);
                },
                onClick: ()=>inputRef.current?.click(),
                className: `cursor-pointer rounded-md border-2 border-dashed p-8 text-center transition-colors ${isDragging ? "border-gn-accent bg-gn-accent-muted" : "border-gn-border bg-gn-surface hover:bg-gn-overlay"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gn-text text-sm font-medium",
                        children: "Drop files here or click to browse"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gn-text-tertiary mt-1 text-xs",
                        children: [
                            "Accepted: PNG, JPEG, WEBP, PDF · up to ",
                            maxMb,
                            " MB each · max 5 files"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "file",
                        multiple: true,
                        accept: accept,
                        className: "hidden",
                        onChange: (e)=>{
                            handleFiles(e.target.files);
                            e.target.value = "";
                        }
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                        lineNumber: 79,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            errors.documents?.map((msg, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gn-danger text-sm",
                    role: "alert",
                    children: msg
                }, i, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                    lineNumber: 93,
                    columnNumber: 9
                }, this)),
            documents.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
                children: documents.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "border-gn-border bg-gn-surface relative overflow-hidden rounded-md border p-2",
                        children: [
                            d.mime.startsWith("image/") ? // eslint-disable-next-line @next/next/no-img-element
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: d.previewUrl,
                                alt: d.name,
                                className: "h-24 w-full rounded object-cover"
                            }, void 0, false, {
                                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                                lineNumber: 107,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gn-overlay text-gn-text-secondary flex h-24 items-center justify-center rounded text-xs font-medium",
                                children: "PDF"
                            }, void 0, false, {
                                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                                lineNumber: 113,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gn-text mt-1 truncate text-xs",
                                title: d.name,
                                children: d.name
                            }, void 0, false, {
                                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                                lineNumber: 117,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gn-text-tertiary text-[10px]",
                                children: [
                                    (d.sizeBytes / 1024).toFixed(1),
                                    " KB"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                                lineNumber: 120,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>removeDocument(d.id),
                                className: "bg-gn-primary/70 text-gn-text-inverse hover:bg-gn-primary absolute right-1 top-1 rounded px-1.5 text-xs",
                                "aria-label": `Remove ${d.name}`,
                                children: "×"
                            }, void 0, false, {
                                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                                lineNumber: 123,
                                columnNumber: 15
                            }, this)
                        ]
                    }, d.id, true, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                        lineNumber: 101,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                lineNumber: 99,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavButtons"], {
                onBack: back,
                onNext: handleNext,
                submitLabel: isEditing ? "Save" : "Next"
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
                lineNumber: 136,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s(StepDocuments, "2dmdnh4p2iy6JlfsqglkcNRo3UQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"]
    ];
});
_c = StepDocuments;
var _c;
__turbopack_context__.k.register(_c, "StepDocuments");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/app/contact/data:fdb8cc [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "submitContactForm",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"602f56dd2fc530049919824013e79c790f07dccec5":{"name":"submitContactForm"}},"apps/gjirafa-news/app/contact/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("602f56dd2fc530049919824013e79c790f07dccec5", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "submitContactForm");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepReview",
    ()=>StepReview
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$app$2f$contact$2f$data$3a$fdb8cc__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/app/contact/data:fdb8cc [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/nav-buttons.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const initialState = {
    ok: false,
    message: ""
};
function StepReview() {
    _s();
    const personal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepReview.useWizard[personal]": (s)=>s.personal
    }["StepReview.useWizard[personal]"]);
    const preferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepReview.useWizard[preferences]": (s)=>s.preferences
    }["StepReview.useWizard[preferences]"]);
    const documents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepReview.useWizard[documents]": (s)=>s.documents
    }["StepReview.useWizard[documents]"]);
    const editStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepReview.useWizard[editStep]": (s)=>s.editStep
    }["StepReview.useWizard[editStep]"]);
    const setStep = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepReview.useWizard[setStep]": (s)=>s.setStep
    }["StepReview.useWizard[setStep]"]);
    const reset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "StepReview.useWizard[reset]": (s)=>s.reset
    }["StepReview.useWizard[reset]"]);
    const [state, formAction, pending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$app$2f$contact$2f$data$3a$fdb8cc__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["submitContactForm"], initialState);
    function handleSubmit(e) {
        e.preventDefault();
        const fd = new FormData();
        fd.set("personal", JSON.stringify(personal));
        fd.set("preferences", JSON.stringify(preferences));
        for (const d of documents)fd.append("documents", d.file, d.name);
        // `formAction` from useActionState must run inside a transition when
        // invoked manually (i.e. not via <form action={formAction}>). Without
        // this wrap, React 19 warns and `pending` won't update correctly.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"])(()=>{
            formAction(fd);
        });
    }
    if (state.ok) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "border-gn-border bg-gn-surface space-y-4 rounded-md border p-6 text-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-gn-text text-xl font-semibold",
                    children: "Thanks — we got your message."
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gn-text-secondary text-sm",
                    children: state.message
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: reset,
                    className: "bg-gn-accent hover:bg-gn-accent-light text-gn-text-inverse rounded-md px-4 py-2 text-sm font-medium transition-colors",
                    children: "Send another"
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        onSubmit: handleSubmit,
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Section, {
                title: "Personal info",
                onEdit: ()=>editStep(1),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                    className: "grid grid-cols-[7rem_1fr] gap-y-1 text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                            className: "text-gn-text-tertiary",
                            children: "Name"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                            className: "text-gn-text",
                            children: personal.name || "—"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                            className: "text-gn-text-tertiary",
                            children: "Email"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 61,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                            className: "text-gn-text",
                            children: personal.email || "—"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                            className: "text-gn-text-tertiary",
                            children: "Phone"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 63,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                            className: "text-gn-text",
                            children: personal.phone || "—"
                        }, void 0, false, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Section, {
                title: "Preferences",
                onEdit: ()=>editStep(2),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PreferencesSummary, {}, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 69,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Section, {
                title: `Documents (${documents.length})`,
                onEdit: ()=>editStep(3),
                children: documents.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gn-text-tertiary text-sm",
                    children: "No files uploaded."
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 77,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    className: "space-y-1 text-sm",
                    children: documents.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "flex justify-between gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gn-text truncate",
                                    children: d.name
                                }, void 0, false, {
                                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                                    lineNumber: 82,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gn-text-tertiary",
                                    children: [
                                        (d.sizeBytes / 1024).toFixed(1),
                                        " KB"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                                    lineNumber: 83,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, d.id, true, {
                            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                            lineNumber: 81,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this),
            state.message && !state.ok && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-gn-danger text-sm",
                "aria-live": "polite",
                children: state.message
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 93,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$nav$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavButtons"], {
                onBack: ()=>setStep(3),
                submitLabel: "Submit",
                pending: pending,
                isSubmit: true
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
        lineNumber: 56,
        columnNumber: 5
    }, this);
}
_s(StepReview, "NNJYFRm+FAH/b7A08/HQx77mQRE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"]
    ];
});
_c = StepReview;
function Section({ title, onEdit, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "border-gn-border bg-gn-surface rounded-md border p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-gn-text font-medium",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 120,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onEdit,
                        className: "text-gn-accent hover:text-gn-accent-light text-xs font-medium underline-offset-2 hover:underline",
                        children: "Edit"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 119,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
        lineNumber: 118,
        columnNumber: 5
    }, this);
}
_c1 = Section;
function PreferencesSummary() {
    _s1();
    const preferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "PreferencesSummary.useWizard[preferences]": (s)=>s.preferences
    }["PreferencesSummary.useWizard[preferences]"]);
    if (!preferences.userType) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-gn-text-tertiary text-sm",
            children: "Not set."
        }, void 0, false, {
            fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
            lineNumber: 137,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
        className: "grid grid-cols-[9rem_1fr] gap-y-1 text-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                className: "text-gn-text-tertiary",
                children: "Type"
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                className: "text-gn-text capitalize",
                children: preferences.userType
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                lineNumber: 142,
                columnNumber: 7
            }, this),
            preferences.userType === "individual" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-gn-text-tertiary",
                        children: "Newsletter"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 145,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "text-gn-text",
                        children: preferences.newsletter ? "Yes" : "No"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 146,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            preferences.userType === "business" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-gn-text-tertiary",
                        children: "Company"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 153,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "text-gn-text",
                        children: preferences.companyName || "—"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 154,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-gn-text-tertiary",
                        children: "VAT"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 155,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "text-gn-text",
                        children: preferences.vatNumber || "—"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 156,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true),
            preferences.userType === "student" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-gn-text-tertiary",
                        children: "University"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 161,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "text-gn-text",
                        children: preferences.university || "—"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-gn-text-tertiary",
                        children: "Graduation"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 163,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "text-gn-text",
                        children: preferences.graduationYear || "—"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
                        lineNumber: 164,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx",
        lineNumber: 140,
        columnNumber: 5
    }, this);
}
_s1(PreferencesSummary, "Bks8Xtf6FZnBaEpbv5yhpUgEfPY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"]
    ];
});
_c2 = PreferencesSummary;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "StepReview");
__turbopack_context__.k.register(_c1, "Section");
__turbopack_context__.k.register(_c2, "PreferencesSummary");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/gjirafa-news/components/contact-wizard/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContactWizard",
    ()=>ContactWizard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.1_@babel+core@7.29.0_@playwright+test@1.59.1_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/lib/contact-wizard/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$stepper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/stepper.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$personal$2d$info$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/step-personal-info.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$preferences$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/step-preferences.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$documents$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/step-documents.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$review$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/gjirafa-news/components/contact-wizard/step-review.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ContactWizard() {
    _s();
    const step = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"])({
        "ContactWizard.useWizard[step]": (s)=>s.step
    }["ContactWizard.useWizard[step]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto w-full max-w-xl space-y-6 p-4 sm:p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "space-y-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-gn-text text-2xl font-semibold",
                        children: "Contact us"
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gn-text-secondary text-sm",
                        children: "Fill in the 4 steps below. Your progress is kept until you submit."
                    }, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$stepper$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Stepper"], {
                current: step
            }, void 0, false, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-gn-border bg-gn-surface rounded-lg border p-4 sm:p-6",
                children: [
                    step === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$personal$2d$info$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepPersonalInfo"], {}, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                        lineNumber: 22,
                        columnNumber: 24
                    }, this),
                    step === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$preferences$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepPreferences"], {}, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                        lineNumber: 23,
                        columnNumber: 24
                    }, this),
                    step === 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$documents$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepDocuments"], {}, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                        lineNumber: 24,
                        columnNumber: 24
                    }, this),
                    step === 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$1_$40$babel$2b$core$40$7$2e$29$2e$0_$40$playwright$2b$test$40$1$2e$59$2e$1_react$2d$dom$40$19$2e$2$2e$4_react$40$19$2e$2$2e$4_$5f$react$40$19$2e$2$2e$4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$components$2f$contact$2d$wizard$2f$step$2d$review$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StepReview"], {}, void 0, false, {
                        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                        lineNumber: 25,
                        columnNumber: 24
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/gjirafa-news/components/contact-wizard/index.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_s(ContactWizard, "wckZZ/SOa3kXCQUa/pcKGjCuiDo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$gjirafa$2d$news$2f$lib$2f$contact$2d$wizard$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWizard"]
    ];
});
_c = ContactWizard;
var _c;
__turbopack_context__.k.register(_c, "ContactWizard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_gjirafa-news_04f75tp._.js.map