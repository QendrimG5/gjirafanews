(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0e~byck._.js","static/chunks/08s2_next_dist_compiled_next-devtools_index_0zndy8d.js","static/chunks/08s2_next_dist_compiled_react-dom_10ifdb_._.js","static/chunks/08s2_next_dist_compiled_react-server-dom-turbopack_10mn6ni._.js","static/chunks/08s2_next_dist_compiled_014i9im._.js","static/chunks/08s2_next_dist_client_10_xxpf._.js","static/chunks/08s2_next_dist_0jy-c~4._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
