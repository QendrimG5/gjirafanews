(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0-ui302._.css","static/chunks/node_modules__pnpm_114tc8f._.js","static/chunks/apps_gjirafa-news_0_flt5z._.js"],
    source: "dynamic"
});
