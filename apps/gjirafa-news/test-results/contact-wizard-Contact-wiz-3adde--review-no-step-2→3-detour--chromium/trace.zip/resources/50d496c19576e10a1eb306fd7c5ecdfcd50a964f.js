(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_gjirafa-news_04f75tp._.js","static/chunks/node_modules__pnpm_0u3rlll._.js"],
    source: "dynamic"
});
